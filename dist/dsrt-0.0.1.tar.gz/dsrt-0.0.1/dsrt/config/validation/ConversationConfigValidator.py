class ConversationConfigValidator:
    def __init__(self, config):
        self.config = config
        
    def validate(self):
        return True